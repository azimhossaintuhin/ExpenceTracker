module.exports = {
    presets: ['babel-preset-expo'],
    plugins: [
      // Add other plugins here (if needed)
      'react-native-reanimated/plugin', // Must be at the end
    ],
  };
  