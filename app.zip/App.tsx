import { AuthProvider } from "./src/context/context"
import Routes from "./src/Routes"
import { QueryClient ,  QueryClientProvider } from "@tanstack/react-query"
 
const  queryClient = new QueryClient()

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
    <AuthProvider>
   <Routes />
   </AuthProvider>
   </QueryClientProvider>

  )
}

export default App