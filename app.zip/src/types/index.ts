import { FlexAlignType  } from "react-native";

export type RootStackParamList = {
    Splash: undefined;
    Login: undefined;
    SignUp: undefined ;
    Home: undefined;
    Details: { id: number };
    Profile: { name: string};
    NotFound: undefined;
}

export type globalContainerType = {
    flex: number;
    justifyContent: "center" | "flex-start" | "flex-end" | "space-between" | "space-around" | "space-evenly";
    alignItems: FlexAlignType;
    backgroundColor: string;
    padding: number;
  
}



export interface InputTypes {
    fieldName: string;
    values: {
      [key: string]: string;
    };
    errors?: {
      [key: string]: string;
    };
    touched?: {
      [key: string]: boolean;
    };
    handleChange?: (name: string) => any;  // Optional function for handleChange
    handleBlur?: (name:string)=>any;    // Optional function for handleBlur
  }