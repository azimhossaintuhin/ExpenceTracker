import { globalContainerType } from "../types"
import { Colors } from "./Colors"

export const Globalcontainer:globalContainerType = {
    flex:1,
    justifyContent:"center",
    alignItems:"center",
    backgroundColor:Colors.white,
    padding:20

}