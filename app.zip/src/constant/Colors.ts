export const  Colors = {
    primary : "#fa8d6f" ,
    secondary : "#fcc566" ,
    white : "#ffffff" ,
    textary : "#73607d" ,
    fourthColor:"#c1b9ae",
    danger:"#ff0000",
    gradiantColor: ["#fa8d6f" , "#fcc566" ]
}